/* ==========================================================================
   Site preloader — short service intro
   ========================================================================== */

(() => {
    "use strict";

    const preloader = document.querySelector(".site-preloader");
    if (!preloader) return;

    const minimumDisplayTime = 650;
    const startedAt = performance.now();
    let hasStartedLeaving = false;

    const leavePreloader = () => {
        if (hasStartedLeaving) return;
        hasStartedLeaving = true;

        const elapsed = performance.now() - startedAt;
        const remaining = Math.max(0, minimumDisplayTime - elapsed);

        window.setTimeout(() => {
            preloader.classList.add("is-leaving");
            preloader.addEventListener("transitionend", (event) => {
                if (event.target === preloader && event.propertyName === "opacity") {
                    preloader.remove();
                }
            }, { once: true });

            window.setTimeout(() => preloader.remove(), 500);
        }, remaining);
    };

    if (document.readyState === "complete") {
        leavePreloader();
    } else {
        window.addEventListener("load", leavePreloader, { once: true });
    }
})();


/* ==========================================================================
   Services section — accessible single-open accordion
   ========================================================================== */

(() => {
    "use strict";

    const accordion = document.querySelector("[data-service-accordion]");
    if (!accordion) return;

    const items = Array.from(accordion.querySelectorAll(".service-item"));

    const setExpandedItem = (selectedItem) => {
        items.forEach((item) => {
            const trigger = item.querySelector(".service-item__toggle");
            const details = item.querySelector(".service-item__details");
            const isExpanded = item === selectedItem;

            item.classList.toggle("is-expanded", isExpanded);
            trigger.setAttribute("aria-expanded", String(isExpanded));
            details.setAttribute("aria-hidden", String(!isExpanded));
        });
    };

    items.forEach((item) => {
        const trigger = item.querySelector(".service-item__toggle");

        trigger.addEventListener("click", () => {
            const isAlreadyExpanded = item.classList.contains("is-expanded");
            if (!isAlreadyExpanded) setExpandedItem(item);
        });
    });

    // Ensure the first service is the only expanded item on initial load.
    setExpandedItem(items[0]);
})();


/* ==========================================================================
   Footer — scroll-triggered highlight entrance
   ========================================================================== */

(() => {
    "use strict";

    const footer = document.querySelector(".site-footer");
    if (!footer) return;

    const reducedMotion = window.matchMedia("(prefers-reduced-motion: reduce)").matches;

    if (reducedMotion || !("IntersectionObserver" in window)) {
        footer.classList.add("is-visible");
        return;
    }

    const observer = new IntersectionObserver((entries, currentObserver) => {
        entries.forEach((entry) => {
            if (!entry.isIntersecting) return;

            footer.classList.add("is-visible");
            currentObserver.unobserve(entry.target);
        });
    }, {
        threshold: 0.28,
        rootMargin: "0px 0px -8% 0px"
    });

    observer.observe(footer);
})();


/* ==========================================================================
   Booking dialog — shared footer and mobile navigation triggers
   ========================================================================== */
(() => {
    "use strict";

    const modal = document.getElementById("booking-modal");
    if (!modal) return;

    const closeButton = modal.querySelector("[data-close-booking]");

    const openModal = () => {
        if (typeof modal.showModal === "function") {
            if (!modal.open) modal.showModal();
        } else {
            modal.setAttribute("open", "");
        }
        document.body.classList.add("booking-modal-open");
    };

    const closeModal = () => {
        if (typeof modal.close === "function" && modal.open) {
            modal.close();
        } else {
            modal.removeAttribute("open");
        }
        document.body.classList.remove("booking-modal-open");
    };

    document.addEventListener("click", (event) => {
        const openTrigger = event.target.closest("[data-open-booking]");
        if (openTrigger) {
            event.preventDefault();
            openModal();
            return;
        }

        if (event.target.closest("[data-close-booking]")) {
            closeModal();
            return;
        }

        if (event.target === modal) closeModal();
    });

    modal.addEventListener("close", () => {
        document.body.classList.remove("booking-modal-open");
    });

    closeButton?.addEventListener("keydown", (event) => {
        if (event.key === "Escape") closeModal();
    });
})();


if (typeof socials !== "undefined" && Array.isArray(socialItems)) {
    socials.innerHTML = socialItems.map((item) => `
        <a class="project-social" href="${item.url}">
            ${item.icon}
        </a>
    `).join("");
}



/* ==========================================================================
   Eventin case study — social sharing
   ========================================================================== */

(() => {
    "use strict";

    const shareLinks = document.querySelectorAll(".project-share__link[data-share]");
    if (!shareLinks.length) return;

    const pageUrl = window.location.href.split("#")[0];
    const pageTitle = document.title;
    const encodedUrl = encodeURIComponent(pageUrl);
    const encodedTitle = encodeURIComponent(pageTitle);

    const shareUrls = {
        facebook: `https://www.facebook.com/sharer/sharer.php?u=${encodedUrl}`,
        twitter: `https://twitter.com/intent/tweet?url=${encodedUrl}&text=${encodedTitle}`,
        linkedin: `https://www.linkedin.com/sharing/share-offsite/?url=${encodedUrl}`,
        whatsapp: `https://api.whatsapp.com/send?text=${encodedTitle}%20${encodedUrl}`
    };

    shareLinks.forEach((link) => {
        const platform = link.dataset.share;
        const shareUrl = shareUrls[platform];
        if (shareUrl) link.href = shareUrl;
    });
})();






/* Universal Page URL Copy Function */

document.querySelectorAll('[data-share="linkcopy"]').forEach((button) => {
    button.addEventListener("click", async (page) => {
        page.preventDefault();

        const pageUrl = window.location.href.split("#")[0];

        try {
            await navigator.clipboard.writeText(pageUrl);

            button.classList.add("is-copied");
            button.setAttribute("aria-label", "Page link copied!");
            button.setAttribute("data-tooltip", "Link copied!");
            button.setAttribute("data-tooltip-visible", "true");
            button.title = "Page link copied!";

            setTimeout(() => {
                button.classList.remove("is-copied");
                button.setAttribute("aria-label", "Copy page link");
                button.removeAttribute("data-tooltip-visible");
                button.title = "";
            }, 2000);

        } catch (error) {
            console.error("Page URL copy failed:", error);
        }
    });
});

